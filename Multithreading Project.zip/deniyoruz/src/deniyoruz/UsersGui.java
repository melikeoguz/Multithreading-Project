
package deniyoruz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class UsersGui extends javax.swing.JFrame {

    
    public UsersGui() {
        initComponents();
    }

           public void initializingProgressBar(float mainServerCapacity, Vector<AltSunucu> subThreads)
    {
        
         Timer timer=new Timer(1000,null);
        
        timer.addActionListener(new ActionListener()
        {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                 
            altSunucu1.setVisible(true);
              altSunucu2.setVisible(true);
                mainThreadsBar.setVisible(true);
                
                
          /*            for(int i=0;i<subThreads.size();i++)
        {
            percentCapacity=(int) subThreads.get(i).percentCapacity;
            System.out.println("\nGUI'ye Gonderilen 1.Kapasite Miktari : "+percentCapacity); 
            altSunucu1.setValue((int) percentCapacity);
          
        }*/
            mainThreadsBar.setValue((int)mainServerCapacity);
            altSunucu1.setValue((int)subThreads.get(0).percentCapacity);
            altSunucu2.setValue((int)subThreads.get(1).percentCapacity);
                
                if( altSunucu1.getValue()>50)
                {
                    altSunucu1.setForeground(Color.red);
                }    
                   
                else if(altSunucu2.getValue()>50 )
                {
                    altSunucu2.setForeground(Color.red);
                }
                
                else if(mainThreadsBar.getValue()>50)
                {
                    mainThreadsBar.setForeground(Color.red);
                }
                
                
               if(  altSunucu1.getValue()==0)
                {
                     System.out.println("1. Alt Sunucunu Kapatildi...");
                      altSunucu1.setVisible(false);
                    // timer.stop();
                }
               
               else if(altSunucu2.getValue()==0)
                {
                    System.out.println("2. Alt Sunucunu Kapatildi...");
                    altSunucu2.setVisible(false);
                }
                
             }
        }
        
        );
        
        timer.start();
             
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainThreadsBar = new javax.swing.JProgressBar();
        jLabel1 = new javax.swing.JLabel();
        altSunucu1 = new javax.swing.JProgressBar();
        altSunucu2 = new javax.swing.JProgressBar();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainThreadsBar.setForeground(new java.awt.Color(0, 204, 51));
        mainThreadsBar.setStringPainted(true);

        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setText("Ana Sunucu Kapasitesi");

        altSunucu1.setForeground(new java.awt.Color(0, 204, 51));
        altSunucu1.setStringPainted(true);

        altSunucu2.setForeground(new java.awt.Color(0, 204, 51));
        altSunucu2.setStringPainted(true);

        jLabel2.setText("1. Alt Sunucu Kapasitesi");

        jLabel3.setText("2. Alt Sunucu Kapasitesi");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(mainThreadsBar, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(186, 186, 186))))
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(altSunucu1, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
                    .addComponent(altSunucu2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(mainThreadsBar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(altSunucu1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(altSunucu2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(204, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar altSunucu1;
    private javax.swing.JProgressBar altSunucu2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JProgressBar mainThreadsBar;
    // End of variables declaration//GEN-END:variables
}
