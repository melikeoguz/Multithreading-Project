
package deniyoruz;

import java.util.Random;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Deniyoruz {
    static BlockingQueue<Integer> sharedQueue = new LinkedBlockingQueue<Integer>();
    static Vector<AltSunucu> subThreads = new Vector<AltSunucu>();
    static int threadNum=0;
    
    
    public static void threadNumArttir(){
        threadNum += 1;
    }
    
    public static void threadOlustur(){
        System.out.println("THREAD OLUSTURULUYOR " +threadNum);
        subThreads.add(new AltSunucu(sharedQueue,threadNum));
        threadNumArttir();
    }
    

    public static void sunucuTakip(){
        int size = subThreads.size();

        System.out.println("\nALT SUNUCU SAYISI : " + size);
        for(int i = 0; i < size; i++){
            System.out.println((i+1) +".thread'in yuzdesi :% " + subThreads.get(i).getPercentCapacity());
        }
    }
    
    
    
    
    public static boolean altSunucuOlusturucu(){
        int size = subThreads.size();
        
        for(int i = 0; i < size+1; i++){
           System.out.println(i + ". kapasitesi : "+subThreads.get(i).getPercentCapacity());
           
           if(subThreads.get(i).getsharedQueueSize() == 0){
               subThreads.get(i).setFlag(false);
           }else if(subThreads.get(i).getPercentCapacity() > 70){
               threadOlustur();
           }
        }
        
        return false;
    }
    
    public static void main(String[] args) {
        Random random = new Random();    
        boolean control;
        
        UsersGui gui=new UsersGui(); /* Arayuzun ekrana bastirilmasi icin obje olusturuldu*/
        gui.setVisible(true);        /* Arayuz ekranda gosteriliyor */
     
    
        /*dokunma, ana sunucu ve ana sunucunun kendi consumer'i  */
        Thread prodThread1 = new Thread(new Server(sharedQueue,1));
        Thread cons_ = new Thread(new Runnable(){ //sadece uçurucu
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Deniyoruz.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    int num = random.nextInt(100);
                    System.out.println("ben anasunucunun consumeri, boyut : " + sharedQueue.size());

                    try {
                        for(int i = 0; i < num ; i++)
                            sharedQueue.take();
                        System.out.println("anasunucu consumeri olarak " + num + " kadar attim gitti, " + sharedQueue.size());
                    } catch (InterruptedException ex) {
                        Logger.getLogger(AltSunucu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
        });
        /* dokunma
            */
        
        threadOlustur();
        threadOlustur();

            Thread controller = new Thread(new Runnable(){
            @Override
            public void run() {
                while(true){
                    
                    System.out.println("\nAna Sunucu Kapasite :% "+ (sharedQueue.size()*100)/500); //Ana Sunucu Kapasitesi 500 alinmistir
                    sunucuTakip();
                    gui.initializingProgressBar((sharedQueue.size()*100)/500,subThreads);
                    
                    //System.out.println("CONTROLLER CALISIYOR");

                    //altSunucuOlusturucu();
                } 
            }

        });
                
        controller.start();
        prodThread1.start();
        subThreads.get(0).start(); //server  calisir
        subThreads.get(1).start(); //ilk alt sunucu calisir
        
        //consThread2.start(); 
        cons_.start();

        try {
            controller.join();
            prodThread1.join();
            subThreads.get(0).join();
            subThreads.get(1).join();
            
            //consThread2.join(); 
            cons_.join();

        } catch (InterruptedException ex) {
                Logger.getLogger(Deniyoruz.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}



