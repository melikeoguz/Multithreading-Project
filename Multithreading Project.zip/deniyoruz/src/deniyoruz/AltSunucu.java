package deniyoruz;


//import static deniyoruz.Deniyoruz.controlThread;
import static deniyoruz.Deniyoruz.threadOlustur;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AltSunucu extends Thread {

    Random random = new Random();
    Deniyoruz dene=new Deniyoruz();
    private final BlockingQueue<Integer> sharedQueue;
    int threadCounter=0;
    private int threadNo;
    float percentCapacity ;
    boolean flag = true;
    
    public AltSunucu (BlockingQueue<Integer> sharedQueue,int threadNo) {
        this.sharedQueue = sharedQueue;
        this.threadNo = threadNo;
    }

    public float getPercentCapacity() {
        return percentCapacity;
    }
    
    public int getsharedQueueSize(){
        return sharedQueue.size();
    }
    
    public void setFlag(boolean flag) {
        this.flag = flag;
    }
    
    @Override
    public void run() {
        while(flag){
            if(flag==false)break;
            System.out.println("consume'dan onceki hal : " + sharedQueue.size());
            try {
                Thread.sleep(200);
                int num = random.nextInt(50);
                
                
                for(int i = 0; i < num; i++){
                    sharedQueue.take();
                }                
                
                System.out.println("Consumed: "+ num + ":by thread:"+threadNo);
                System.out.println("consume'dan sonraki hal : " + sharedQueue.size());
                
            } catch (Exception err) {
               err.printStackTrace();
            }
            
            percentCapacity=((this.sharedQueue.size()*100)/500);   //Alt Sunucularin kapasiteleri degisken olabilir. Simdilik istek kapasitesi 500 alinmistir 
             
        }
    }   
}


