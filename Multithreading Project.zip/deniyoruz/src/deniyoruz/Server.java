
package deniyoruz;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server implements Runnable {
    Random random = new Random();

    private Lock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();
    
    private final BlockingQueue<Integer> sharedQueue;
    private int threadNo;

    public Server(BlockingQueue<Integer> sharedQueue,int threadNo) {
        this.threadNo = threadNo;
        this.sharedQueue = sharedQueue;
    }

    @Override
    public void run() {
        for(;;){
            try {
                Thread.sleep(100);
            } catch (Exception err) {
                err.printStackTrace();
            }
            
            System.out.println("100ms uyudum");
            int indexNumber = random.nextInt(100);//kac tane ekleyecegi
            System.out.println(indexNumber + "+");
            
            lock.lock();
            //if(sharedQueue.size() >= 1000) System.out.println("_)*(&^%$#doldummmm " + sharedQueue.size());
            for(int i = 0; i < indexNumber ; i++){
                int number= random.nextInt(100); //indisin icindeki rastgele sayi
                try {
                    sharedQueue.put(number);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            lock.unlock();
            
            System.out.println("Server sharedQueue : " +sharedQueue.size());

        }
    }
}



